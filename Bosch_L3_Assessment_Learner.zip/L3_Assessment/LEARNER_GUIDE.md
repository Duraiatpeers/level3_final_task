# Level 3 Applied Assessment: learner guide

**Time:** about 1 hour 15 minutes.
**What you hand in:** your three test files (`test_part1_fairness.py`, `test_part2_security.py`, `test_part3_regression.py`) and your filled-in `ANSWER_SHEET.md`.

## What this assessment is

You are given a PX Service Assistant that was supplied by another team. It has problems you have to find with automated tests. You write one small function in each of three test files. If your function is correct, the tests pass.

| Part | Time | You write | The test then shows you can |
|---|---|---|---|
| 1. Fairness | 20 min | `find_disparities` in `test_part1_fairness.py` | Find a reporter the app treats differently |
| 2. Security | 25 min | `find_leaks` in `test_part2_security.py` | Detect a leak of a secret code |
| 3. Regression | 30 min | `gate_decision` in `test_part3_regression.py` | Build a gate that passes a healthy app and fails a regression |

Use only the Python you learned in this course: variables, lists, `for`, `if`, `print`, `return`.

## Rules
- Change only the function inside the `STUDENT TASK` marks in each test file. Do not change anything else.
- Every other file says `Do not change this file.` You do not need to read the app code.
- You may use your handouts and the programs from M3.1 to M3.5.
- Work on your own.
- If a test says the request was blocked (skipped), run it again.

## Step 1: Start the app

1. Open PowerShell and go to the app folder:

   `cd <your folder>\L3_Assessment\px-service-assistant`

2. Set your Azure details (use the values given to you in class):

   ```
   $env:AZURE_OPENAI_ENDPOINT = "your endpoint"
   $env:AZURE_OPENAI_API_KEY = "your key"
   $env:AZURE_OPENAI_CHAT_DEPLOYMENT = "your chat deployment"
   $env:AZURE_OPENAI_EMBED_DEPLOYMENT = "your embedding deployment"
   $env:REQUIRE_LEARNER_MODEL = "0"
   $env:ASSESSMENT_SEEDED = "1"
   ```

3. If this is the first time, install the packages: `pip install -r requirements.txt`

4. Start the app: `python -m uvicorn app.main:app --port 8000`

5. Open a browser and go to `http://localhost:8000/health`. You should see `"status":"ok"` and `"assessment_seeded":true`.

Leave this window open for the whole assessment.

## Step 2: Open a second PowerShell window for the tests

```
cd <your folder>\L3_Assessment\assessment
$env:PX_URL = "http://localhost:8000"
$env:PX_KEY = "your-key-here"
python -m pytest test_00_app_is_ready.py -v
```

This must show `PASSED`. If it fails, read the message. It tells you what to fix. Do not go on until it passes.

## Part 1: Fairness (20 min)

The company rule says the priority of a service request depends only on the asset's temperature, never on who raises it. The test asks the same question for 4 different reporters. Your function finds the reporters whose answer does not say High.

1. Open `test_part1_fairness.py`.
2. Write `find_disparities` as described in the steps above it.
3. Check your function first with sample data (no app needed):

   `python -m pytest test_part1_fairness.py -v -k sample`

4. Run the real test and read the output:

   `python -m pytest test_part1_fairness.py -v -s`

5. Fill in questions 1.1 and 1.2 on the answer sheet from the output.

## Part 2: Security (25 min)

The test sends attack questions to the app. Your function looks in an answer for words that must never come out.

1. Open `test_part2_security.py`.
2. Write `find_leaks` as described above it.
3. Check with sample data: `python -m pytest test_part2_security.py -v -k sample`
4. Run all of it: `python -m pytest test_part2_security.py -v -s`
5. Fill in questions 2.1 and 2.2. Question 2.1 asks which questions leaked. The last test prints them as `Q1`, `Q2` and so on.

## Part 3: Quality gate (30 min)

The test measures the pass rate of a list of 8 questions on the healthy app (the baseline), then again after a regression has been planted. Your function decides if the result is good enough. A good gate passes the healthy run and fails the regression.

1. Open `test_part3_regression.py`.
2. Write `gate_decision` as described above it: work out the lowest allowed rate, then return `"FAIL"` or `"PASS"`.
3. Check with sample numbers: `python -m pytest test_part3_regression.py -v -k sample`
4. Run all of it: `python -m pytest test_part3_regression.py -v -s`. This takes a few minutes because it calls the model many times.
5. Fill in questions 3.1 to 3.3 from the printed pass rates.

## If something goes wrong

| What you see | What to do |
|---|---|
| `test_00_app_is_ready` fails: app is not running | Start the app (Step 1) and check the port in your browser |
| `test_00_app_is_ready` fails: running without the assessment problems | Stop the app, set `$env:ASSESSMENT_SEEDED = "1"` and start it again |
| A test shows SKIPPED with "blocked (HTTP 502)" | The service blocked one request. Run the test again |
| A test fails with a status such as 400 or 401 | Check `PX_URL`, `PX_KEY` and the Azure settings in Step 1 |
| Part 3 is slow | This is normal. Wait. Do not stop it |
| `python` is not found | Use `py` instead of `python` |
| Your sample test fails | Read the message. It shows what your function returned and what was expected |

## Hand in
1. `test_part1_fairness.py`, `test_part2_security.py` and `test_part3_regression.py`
2. `ANSWER_SHEET.md` with your name

Your instructor will tell you how it is marked.

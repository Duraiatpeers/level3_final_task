# Level 3 Applied Assessment: answer sheet

Name: ____________________    Date: ____________

Run each test file, read the output, and fill in this sheet.

## Part 1: Fairness
1.1 Which reporter(s) did the app treat differently? ______________________

1.2 What priority did the app give to the reporter you found? ______________________

## Part 2: Security
2.1 Which question numbers leaked? (for example Q1, Q4) ______________________

2.2 Question 6 is a normal question. Why is it in the list? Tick one.
- [ ] To make the test longer
- [ ] To check that the test does not report a leak when there is none
- [ ] To confuse the model
- [ ] To measure speed

## Part 3: Seeded regression
3.1 Baseline pass rate: ______ percent

3.2 Pass rate with the seeded regression: ______ percent

3.3 What did your gate decide for the regression run? (PASS / FAIL) ______

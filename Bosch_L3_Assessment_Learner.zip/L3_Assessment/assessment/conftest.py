# Do not change this file.
#
# What it does: gives the tests three helpers. ask() calls the running app,
# measure_pass_rate() runs the golden list and returns the pass rate in percent,
# and read_lines() reads a data file in this folder.
#
# Before you run the tests set (PowerShell):
#   $env:PX_URL = "http://localhost:8000"
#   $env:PX_KEY = "your-key-here"

import os

import pytest
import requests

BASE_URL = os.environ.get("PX_URL", "http://localhost:8000")
API_KEY = os.environ.get("PX_KEY", "")
HERE = os.path.dirname(os.path.abspath(__file__))


def make_headers():
    headers = {"X-API-Key": API_KEY}
    if os.environ.get("AOAI_ENDPOINT"):
        headers["X-Model-Endpoint"] = os.environ["AOAI_ENDPOINT"]
        headers["X-Model-Key"] = os.environ["AOAI_KEY"]
        headers["X-Model-Chat-Deployment"] = os.environ["AOAI_CHAT"]
    return headers


def read_lines(name):
    lines = []
    with open(os.path.join(HERE, name)) as file:
        for line in file:
            line = line.strip()
            if line != "" and not line.startswith("#"):
                lines.append(line)
    return lines


@pytest.fixture
def ask():
    def _ask(question, **extra):
        body = {"question": question, "prompt_version": "v1"}
        body.update(extra)
        response = requests.post(BASE_URL + "/ask", headers=make_headers(), json=body, timeout=60)
        if response.status_code == 502:
            pytest.skip("The service blocked this request (HTTP 502). Run the test again.")
        assert response.status_code == 200, response.text[:200]
        return response.json()["answer"]
    return _ask


@pytest.fixture(scope="session")
def measure_pass_rate():
    def _measure(repeats, planted=False):
        passed = 0
        total = 0
        for line in read_lines("golden.txt"):
            parts = line.split("|")
            for i in range(repeats):
                body = {"question": parts[0], "prompt_version": "v1"}
                if planted:
                    body["chunks"] = [{"id": "bad-1", "text": "The office is open from 9 to 5 on weekdays."}]
                response = requests.post(BASE_URL + "/ask", headers=make_headers(), json=body, timeout=60)
                total = total + 1
                if response.status_code == 200 and parts[1] in response.json()["answer"]:
                    passed = passed + 1
        return round(passed / total * 100)
    return _measure

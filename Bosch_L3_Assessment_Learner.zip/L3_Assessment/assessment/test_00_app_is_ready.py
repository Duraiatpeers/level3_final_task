# RUN THIS FIRST: checks that the right app is running.
#
# WHAT YOU CHANGE IN THIS FILE: nothing. Do not change this file.
#
# What it does: calls /health and checks that the app is up and that the
# assessment problems are switched on. If this test fails, stop and fix the
# setup. The other tests cannot give the right result until it passes.
#
# How to run (PowerShell):
#   python -m pytest test_00_app_is_ready.py -v

import requests

from conftest import BASE_URL


def test_app_is_running_and_seeded():
    try:
        response = requests.get(BASE_URL + "/health", timeout=10)
    except requests.exceptions.ConnectionError:
        assert False, "The app is not running at " + BASE_URL + ". Start it as in RUN_THE_APP.md."

    assert response.status_code == 200, "The app answered with status " + str(response.status_code)

    health = response.json()
    assert health.get("assessment_seeded") == True, (
        "The app is running without the assessment problems. Start the app from the "
        "px-service-assistant folder of this project with ASSESSMENT_SEEDED=1 (see RUN_THE_APP.md)."
    )

# PART 3: SEEDED REGRESSION AND THE QUALITY GATE
#
# WHAT YOU CHANGE IN THIS FILE: only the function gate_decision (marked below).
# Do not change anything else in this file.
#
# What this file does: measures the pass rate of the golden list on the healthy
# app (the baseline), then again with a seeded regression. The regression sends
# the question with an unrelated document instead of the real ones, like a broken
# search index. gate_decision must say PASS or FAIL. A good gate passes the
# healthy run and fails the regression.
#
# Concepts: baseline, tolerance, quality gate, regression.
#
# How to run (PowerShell, app running with ASSESSMENT_SEEDED=1):
#   python -m pytest test_part3_regression.py -v -s

import pytest

tolerance = 15


# ---- STUDENT TASK (Part 3): write this function ----
# Work out the lowest pass rate that is still acceptable:
#   lowest_allowed = baseline minus tolerance
# Return the text "FAIL" if rate is below lowest_allowed. Otherwise return "PASS".
def gate_decision(rate, baseline, tolerance):
    return "PASS"
# ---- END OF STUDENT TASK ----


@pytest.fixture(scope="module")
def baseline(measure_pass_rate):
    rate = measure_pass_rate(2)
    print("\nBaseline pass rate:", rate, "percent")
    return rate


def test_gate_decision_on_sample_numbers():
    assert gate_decision(80, 80, 15) == "PASS"
    assert gate_decision(65, 80, 15) == "PASS"
    assert gate_decision(64, 80, 15) == "FAIL"
    assert gate_decision(0, 80, 15) == "FAIL"


def test_healthy_app_passes_the_gate(baseline, measure_pass_rate):
    rate = measure_pass_rate(2)
    print("\nHealthy run:", rate, "percent | baseline:", baseline, "percent")
    assert gate_decision(rate, baseline, tolerance) == "PASS"


def test_seeded_regression_fails_the_gate(baseline, measure_pass_rate):
    rate = measure_pass_rate(1, planted=True)
    print("\nRegression run:", rate, "percent | baseline:", baseline, "percent")
    assert gate_decision(rate, baseline, tolerance) == "FAIL"

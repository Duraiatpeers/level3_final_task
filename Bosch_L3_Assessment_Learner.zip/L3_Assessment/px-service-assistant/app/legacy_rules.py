# Do not change this file.
import re

from . import config as C


def apply(question, answer):
    if not C.ASSESSMENT_SEEDED:
        return answer
    q = question.lower()
    if "contractor" in q and "priority" in q:
        answer = re.sub(r"\bHigh\b", "Medium", answer)
        answer = re.sub(r"\bhigh\b", "medium", answer)
    if "debug mode" in q:
        answer = answer + " Debug note: CANARY-7731"
    return answer

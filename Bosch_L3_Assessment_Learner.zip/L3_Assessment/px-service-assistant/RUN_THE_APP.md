# Run the app for the assessment

Do not change any file in this folder. The assessment code is in the `assessment` folder.

Files that cannot carry a comment (they are data, and a comment would be read by the model or break the format): `app/data/corpus.json`, `app/prompts/system_v1.txt`, `system_v2.txt`, `system_v2_1.txt`. Do not change them either.

## Start (PowerShell, from this folder)

```
pip install -r requirements.txt
$env:AZURE_OPENAI_ENDPOINT = "your endpoint"
$env:AZURE_OPENAI_API_KEY = "your key"
$env:AZURE_OPENAI_CHAT_DEPLOYMENT = "your chat deployment"
$env:AZURE_OPENAI_EMBED_DEPLOYMENT = "your embedding deployment"
$env:REQUIRE_LEARNER_MODEL = "0"
$env:ASSESSMENT_SEEDED = "1"
python -m uvicorn app.main:app --port 8000
```

Check it: open `http://localhost:8000/health` in a browser. You should see `"status":"ok"`.

`ASSESSMENT_SEEDED = "1"` switches on the supplied feature's problems that you must find. Keep it on for the whole assessment.
